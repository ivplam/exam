public class SimpleNotepad extends INotepadImpl {

}
