public class EncryptedNotepad extends INotepadImpl {

    private final String password;

    public EncryptedNotepad(String password) {
        super();
        this.password = password;
    }

    private boolean checkPassword(String inputPassword) {
        if (!password.equals(inputPassword)) {
            System.out.println("Invalid pass");
            return false;
        }
        return true;
    }

    public void createAndWritePage(String inputPassword, String title, String text) {
        if (checkPassword(inputPassword)) {
            super.createAndWritePage(title, text);
        }
    }

    public void writeOnPage(String inputPassword, int pageNumber, String text) {
        if (checkPassword(inputPassword)) {
            super.writeOnPage(pageNumber, text);
        }
    }

    public void deleteTextOnPage(String inputPassword, int pageNumber) {
        if (checkPassword(inputPassword)) {
            super.deleteTextOnPage(pageNumber);
        }
    }

    public void viewAllPages(String inputPassword) {
        if (checkPassword(inputPassword)) {
            super.viewAllPages();
        }
    }
}