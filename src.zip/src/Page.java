public class Page {
    private String title;
    private String text;
    private Integer number;

    public Page(String title, int number,String text) {
        this.title = title;
        this.number = number;
        this.text = text;
    }

    public void addText(String text) {
        this.text = this.text + text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String pageInfo() {
        return title + "\n" + text;
    }

    public String getTitle() {
        return title;
    }

    public Integer getNumber() {
        return number;
    }
}
