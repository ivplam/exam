import java.util.ArrayList;
import java.util.List;


public abstract class INotepadImpl implements INotepad {

    protected List<Page> pages;

    public INotepadImpl() {
        this.pages = new ArrayList<>();
    }

    @Override
    public void createAndWritePage(String title, String text) {
        Page page = new Page(title, pages.size() + 1, text);
        pages.add(page);
    }

    @Override
    public void writeOnPage(int pageNumber, String text) {
        for (int i = 0; i < pages.size(); i++) {
            Page currentPage = pages.get(i);
            if (currentPage.getNumber() == pageNumber) {
                Page newPage = new Page(currentPage.getTitle(), pageNumber, text);
                pages.set(i, newPage);
                return;
            }
        }
        System.out.println("Page not found!");
    }


    @Override
    public void deleteTextOnPage(int pageNumber) {
        for (int i = 0; i < pages.size(); i++) {
            Page currentPage = pages.get(i);
            if (currentPage.getNumber() == pageNumber) {
                Page newPage = new Page(currentPage.getTitle(), pageNumber, "");
                pages.set(i, newPage);
                return;
            }
        }
        System.out.println("Page not found!");
    }

    @Override
    public void viewAllPages() {
        for (Page page : pages) {
            System.out.println(page.pageInfo());
        }

    }
}
