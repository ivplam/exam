interface INotepad {
 void createAndWritePage (String title, String text);
 void writeOnPage (int pageNumber, String text);
 void deleteTextOnPage (int pageNumber);
 void viewAllPages ();
}
