//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        testForEncryptedNotepad();
    }

    private static void testForSimpleNotepad() {
        SimpleNotepad simpleNotepad = new SimpleNotepad();
        simpleNotepad.createAndWritePage("Page 1", "Hello, World!");
        simpleNotepad.createAndWritePage("Page 2", "Second page content");

        simpleNotepad.writeOnPage(1, "Updated content for page 1");
        simpleNotepad.deleteTextOnPage(2);

        simpleNotepad.viewAllPages();
    }

    private static void testForEncryptedNotepad() {
        EncryptedNotepad notepad = new EncryptedNotepad("parola123");

        notepad.createAndWritePage("parola123", "title", "text here");
        notepad.viewAllPages("wrong");
        notepad.viewAllPages("parola123");
    }
}